"use client";

import { useState, useEffect } from "react";
import { Ticket, Plus, Trash2, Percent } from "lucide-react";

type Coupon = { id: string; code: string; discountPercentage: number; isActive: boolean; createdAt: string };

export default function CouponManager() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  
  // New Coupon State
  const [code, setCode] = useState("");
  const [discount, setDiscount] = useState("");

  const fetchCoupons = async () => {
    setLoading(true);
    const res = await fetch('/api/coupons');
    if (res.ok) setCoupons(await res.json());
    setLoading(false);
  };

  useEffect(() => { fetchCoupons(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !discount) return;
    
    await fetch('/api/coupons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        code: code.toUpperCase(), 
        discountPercentage: parseInt(discount),
        isActive: true 
      })
    });
    setCode(""); setDiscount("");
    fetchCoupons();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/coupons/${id}`, { method: 'DELETE' });
    fetchCoupons();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 md:space-y-8">
      
      <div className="bg-white p-6 md:p-8 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-8 items-start md:items-center justify-between">
         <div>
            <h1 className="text-2xl md:text-3xl font-bold text-primary flex items-center gap-3">
              <div className="p-3 bg-brand-blue/10 rounded-2xl"><Ticket className="text-brand-blue" size={28} /></div>
              Promo Codes
            </h1>
            <p className="text-sm text-gray-500 font-medium mt-2">Create and manage discounts for your storefront.</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        
        {/* CREATE FORM */}
        <div className="lg:col-span-1">
           <form onSubmit={handleCreate} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4 sticky top-24">
              <h2 className="font-bold text-primary mb-4 text-lg">New Coupon</h2>
              <div>
                 <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-bold">Code (e.g. SUMMER20)</label>
                 <input type="text" required className="w-full bg-canvas border border-gray-200 rounded-xl p-4 text-primary font-mono outline-none focus:border-brand-blue uppercase" value={code} onChange={(e) => setCode(e.target.value)} />
              </div>
              <div>
                 <label className="block text-xs uppercase tracking-wider text-gray-500 mb-2 font-bold">Discount Percentage</label>
                 <div className="relative">
                    <Percent className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input type="number" required min="1" max="100" className="w-full bg-canvas border border-gray-200 rounded-xl p-4 pl-12 text-primary font-mono outline-none focus:border-brand-blue" value={discount} onChange={(e) => setDiscount(e.target.value)} />
                 </div>
              </div>
              <button type="submit" className="w-full bg-brand-blue text-white p-4 rounded-xl font-bold hover:bg-blue-700 transition-all flex justify-center items-center gap-2 mt-2">
                 <Plus size={20} /> Create Code
              </button>
           </form>
        </div>

        {/* COUPON LIST */}
        <div className="lg:col-span-2 space-y-4">
           {loading ? (
             <div className="p-10 text-center text-gray-400 font-bold">Loading codes...</div>
           ) : coupons.length === 0 ? (
             <div className="bg-white p-10 rounded-3xl border border-gray-100 border-dashed text-center">
                <p className="text-gray-500 font-medium">No active promo codes. Create one to get started.</p>
             </div>
           ) : (
             coupons.map((coupon) => (
                <div key={coupon.id} className="bg-white p-5 md:p-6 rounded-2xl border border-gray-100 shadow-sm flex justify-between items-center group">
                   <div className="flex items-center gap-4 md:gap-6">
                      <div className="w-16 h-16 md:w-20 md:h-20 bg-canvas rounded-2xl flex flex-col items-center justify-center border border-gray-200">
                         <span className="text-xl md:text-2xl font-black text-brand-blue">{coupon.discountPercentage}%</span>
                         <span className="text-[10px] text-gray-500 font-bold uppercase">OFF</span>
                      </div>
                      <div>
                         <h3 className="text-lg md:text-xl font-black font-mono text-primary tracking-tight">{coupon.code}</h3>
                         <div className="flex items-center gap-2 mt-1">
                           <span className="w-2 h-2 rounded-full bg-green-500"></span>
                           <span className="text-xs text-gray-500 font-bold">Active</span>
                         </div>
                      </div>
                   </div>
                   <button onClick={() => handleDelete(coupon.id)} className="p-3 md:p-4 text-gray-400 hover:text-brand-orange hover:bg-orange-50 rounded-xl transition-colors">
                      <Trash2 size={20} />
                   </button>
                </div>
             ))
           )}
        </div>

      </div>
    </div>
  );
}